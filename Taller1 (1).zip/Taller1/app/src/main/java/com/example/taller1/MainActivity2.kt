package com.example.taller1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class MainActivity2 : AppCompatActivity() {
    val arreglo:MutableList<String> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val lista = findViewById<ListView>(R.id.lista1)
        val adaptador = ArrayAdapter(this, android.R.layout.simple_list_item_1, arreglo)
        val categoria = intent.getStringExtra("categoria")
        val favoritos = intent.getParcelableArrayListExtra<Bundle>("favoritos")
        val intent = Intent(this, MainActivity3::class.java)
        val bundle= Bundle()



        lista.adapter = adaptador

        if (categoria != null) {
            llenarArreglo(categoria)
        }

            llenarArreglo2(favoritos)



        lista.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->
               val nombre = parent.getItemAtPosition(position).toString()
                llenarBundle(bundle, nombre)
                intent.putExtra("destino",bundle)
                startActivity(intent)
            }

    }

    private fun llenarArreglo2(favoritos: ArrayList<Bundle>?) {
        if (favoritos != null) {
            for (i in 0 until favoritos.size){
                favoritos[i].getString("nombre")?.let { arreglo.add(it) }
            }

        }
    }

    private fun llenarBundle(bundle: Bundle, nombre: String) {
        val json = JSONObject(loadJSONFromAsset())
        val paisesJson = json.getJSONArray("destinos")

        for(i in 0 until paisesJson.length()) {
            val jsonObject = paisesJson.getJSONObject(i)

            if (jsonObject.getString("nombre") == nombre)
            {
                bundle.putString("nombre", jsonObject.getString("nombre"))
                bundle.putString("pais", jsonObject.getString("pais"))
                bundle.putString("categoria", jsonObject.getString("categoria"))
                bundle.putString("plan", jsonObject.getString("plan"))
                bundle.putString("precio", jsonObject.getString("precio"))
            }

        }

    }

    fun loadJSONFromAsset(): String? {
        var json: String? = null
        try{
            val istream: InputStream = assets. open( "destinos.json")
            val size: Int = istream.available()
            val buffer = ByteArray(size)
            istream. read (buffer)
            istream.close()
            json = String(buffer, Charsets. UTF_8)
        }catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }
    private fun llenarArreglo(categoria:String){
        val json = JSONObject(loadJSONFromAsset())
        val paisesJson = json.getJSONArray("destinos")

        for(i in 0 until paisesJson.length()) {
            val jsonObject = paisesJson.getJSONObject(i)
            if ("Todos" == categoria){
                arreglo.add(jsonObject.getString("nombre"))
            }

            else if (jsonObject.getString("categoria") == categoria)
            {
                arreglo.add(jsonObject.getString("nombre"))
            }

        }

    }

}