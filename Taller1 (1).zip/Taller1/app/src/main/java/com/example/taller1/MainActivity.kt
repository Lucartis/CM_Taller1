package com.example.taller1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener{

    companion object {
        val listaFavoritos: MutableList<Bundle> = mutableListOf()
    }

    lateinit var categoria:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val spinner= findViewById<Spinner>(R.id.spinner)
        val intent = Intent(this, MainActivity2::class.java)
        val intent2 = Intent(this, MainActivity2::class.java)
        val intent3 = Intent(this, MainActivity3::class.java)


        button1.setOnClickListener{
        intent.putExtra("categoria",categoria)
        startActivity(intent)
        }

        button2.setOnClickListener{
            intent2.putParcelableArrayListExtra("favoritos", ArrayList(listaFavoritos))
            startActivity(intent2)
        }

        button3.setOnClickListener {
            val categoriaMasFrecuente = obtenerCategoriaMasFrecuente(listaFavoritos)
            val destinosCategoriaMasFrecuente = filtrarPorCategoria(listaFavoritos, categoriaMasFrecuente.toString())

            if (destinosCategoriaMasFrecuente.isEmpty()) {
                intent3.putExtra("recomendacion", "NA")
            } else {
                val destinoAleatorio = destinosCategoriaMasFrecuente.random()
                intent3.putExtra("recomendacion", destinoAleatorio)
            }
            startActivity(intent3)
        }
        spinner.onItemSelectedListener = this


    }

    private fun filtrarPorCategoria(listaFavoritos: MutableList<Bundle>, categoria: String): List<Bundle> {
        return listaFavoritos.filter { it.getString("categoria") == categoria }
    }

    private fun obtenerCategoriaMasFrecuente(listaFavoritos: MutableList<Bundle>): String {
        val contadorCategorias = listaFavoritos.groupingBy { it.getString("categoria") }.eachCount()
        return contadorCategorias.maxByOrNull { it.value }?.key ?: "NA"
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        if (parent != null) {
            Toast.makeText(baseContext, parent.selectedItem.toString(),
                Toast.LENGTH_LONG).show()
            categoria=parent.selectedItem.toString()
        }


    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}