package com.example.taller1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.IOException
import java.io.InputStream

class MainActivity3 : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val bundle:Bundle? = intent.getBundleExtra("destino")
        val bundle2:Bundle? = intent.getBundleExtra("recomendacion")

        val boton=findViewById<Button>(R.id.buttonF)


        if (bundle != null) {
            imprimirBundle(bundle)
        }
        else if (bundle2 != null) {
            imprimirBundle(bundle2)
        }
     


    boton.setOnClickListener{
        if (bundle != null) {
           if( revision(bundle)){
               MainActivity.listaFavoritos.add(bundle)
               Toast.makeText(baseContext, "Añadido a favoritos", Toast.LENGTH_LONG).show()
           }
            else
               Toast.makeText(baseContext, "Ya estaba añadido a favoritos", Toast.LENGTH_LONG).show()

        }
        boton.isEnabled = false

    }

    }

    private fun imprimirBundle(bundle: Bundle) {
        val texto1 = findViewById<TextView>(R.id.textView1)
        val texto2 = findViewById<TextView>(R.id.textView2)
        val texto3 = findViewById<TextView>(R.id.textView3)
        val texto4 = findViewById<TextView>(R.id.textView4)
        val texto5 = findViewById<TextView>(R.id.textView5)

        texto1.text=bundle.getString("nombre")
        texto2.text=bundle.getString("pais")
        texto3.text=bundle.getString("categoria")
        texto4.text=bundle.getString("plan")
        texto5.text=bundle.getString("precio")
    }

    fun revision(bundle:Bundle): Boolean {
        for (i in MainActivity.listaFavoritos)
        {
            if (i.getString("nombre") == bundle.getString("nombre"))
                return false
        }
        return true
    }

}